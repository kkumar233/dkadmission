<!-- footer.php -->
<footer class="bg-dark text-white text-center py-3 mt-auto">
  &copy; <?php echo date("Y"); ?> DK Admission Consulting. All rights reserved.
</footer>
